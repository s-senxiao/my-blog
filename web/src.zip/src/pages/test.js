import React, { Component } from 'react';

export default class home extends Component {
  constructor (props) {
    super(props);
    this.state = {};
  }

  render () {
    return (
      <div class="home">
        home page
      </div>
    )
  }
}

