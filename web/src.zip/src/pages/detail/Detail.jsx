import React from 'react';
import { CalendarOutlined } from '@ant-design/icons'
import './style.scss'

function App() {
  return (
    <div className="page-container page-container-detail">
      <div className="post">
        <div className="post-title">常凯申与双鸭山大学</div>
        <div className="post-meta">
          <CalendarOutlined />
          <span className="date">2019-06-01</span>
        </div>
        <div className="post-content">
        <p>常凯申是谁？这要从清华大学历史系副主任王奇闹的一个学术笑话说起。王奇在2008年10月出版的《中俄国界东段学术史研究：中国、俄国、西方学者视野中的中俄国界东段问题》一书中，发生了多处翻译谬误，其中最荒唐的，当属蒋介石（Chiang Kai-shek）被改名为“常凯申”。后经网络扩散，从此，常凯申声名鹊起，家喻户晓。<a id="more"></a></p>
        <p>而“双鸭山大学”则是根据中山大学（Sun Yat-sen University）趣味音译过来的。孙中山先生，名文，又号逸仙（Sun Yat-sen ）。</p>
        </div>
      </div>
    </div>
  );
}

export default App;
