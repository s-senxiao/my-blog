import React from 'react';
import { Link } from 'react-router-dom'
import { CalendarOutlined } from '@ant-design/icons'
import './style.scss'

class App extends React.Component {
  constructor (props) {
    super(props)
  }

  render () {
    fetch('/api/article/list', {
      method: 'get',
      headers: { "Content-Type": "application/json; charset=utf-8" }
    })
    .then(res => res.json())
    .then(data => {
      // this.articleList = data.data
      this.state.listItems = data.data.map((item) => (
        <div className="post">
          <div className="post-title">
            <Link to="/detail/{item._id}">{item.title}</Link>
          </div>
          <div className="post-meta">
            <CalendarOutlined />
            <span className="date">2020-07-26</span>
          </div>
          <div className="post-content">
            {item.content}
          </div>
        </div>
      ))
      // console.log(1111, this.state.listItems)
    })

    // function renderPage (listItems) {
    //   return (
    //     <div className="page-container page-container-home">
    //       {listItems}
    //     </div>
    //   )
    // }

    return (
      <div className="page-container page-container-home">
        {this.state.listItems}
      </div>
    )
  }
}

export default App;
