import React from 'react'
import { Form, Input, Button, Checkbox } from 'antd'
import './style.scss'

const { TextArea } = Input
class App extends React.Component {
  constructor (props) {
    super(props)
  }

  render () {
    function handlePublish (data) {
      fetch('/api/admin/publish', {
        method: 'POST',
        body: JSON.stringify(data),
        headers: { "Content-Type": "application/json; charset=utf-8" }
      })
    }
    return (
      <div className="page-container page-container-admin">
        <Form name="form" onFinish={handlePublish}>
          <Form.Item label="标题" name="title">
            <Input />
          </Form.Item>
          <Form.Item label="内容" name="content">
            <TextArea type="textarea" rows={5}/>
          </Form.Item>
          <Form.Item label="分类" name="category">
            <Input />
          </Form.Item>
          <Form.Item label="标签" name="tag">
            <Input />
          </Form.Item>
          <Form.Item>
            <Button type="primary" htmlType="submit">发布</Button>
            <Button htmlType="submit">保存</Button>
          </Form.Item>
        </Form>
      </div>
    );
  }
}

export default App;
