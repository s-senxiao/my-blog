import React from 'react';
import './style.scss'

function App() {
  return (
    <div className="page-container page-container-about">
      this is about page
    </div>
  );
}

export default App;
